# 🎥 Script Vidéo LinkedIn — Présentation Internship Codveda Power BI

> **Durée cible** : 2 min 30 sec – 3 min  
> **Format** : Screen recording + voix off + caméra optionnelle  
> **Outil recommandé** : Loom, OBS Studio, ou Windows Game Bar (Win+G)

---

## STRUCTURE DE LA VIDÉO

### [00:00 – 00:15] Introduction — Accroche

🎤 **Script** :
> "Bonjour ! Je suis Khalid Ag Mohamed Aly, étudiant en Science Politique avec spécialisation IA à l'Université Centrale de Tunis.
> Dans cette vidéo, je vous présente mon projet d'internship réalisé avec Codveda Technologies :
> un pipeline complet d'analyse de données avec Power BI, de la donnée brute aux insights actionnables."

📹 **Visuels** : Caméra face — sourire, fond professionnel ou bureau propre

---

### [00:15 – 00:45] Vue d'ensemble du projet

🎤 **Script** :
> "J'ai travaillé sur 5 datasets réels représentant 4 763 enregistrements :
> des données de churn télécom, d'analyse de sentiment sur les réseaux sociaux,
> le dataset Iris pour la classification botanique, et les prix immobiliers de Boston.
>
> Commençons par la vue d'ensemble du dashboard."

📹 **Visuels** :
- Passer sur l'onglet **Overview** du dashboard
- Montrer les 5 KPI cards en haut
- Survoler le graphique "Dataset Size Comparison"
- Montrer la section "Data Quality Summary"

💡 **Point clé à mentionner** : "Le dataset Boston Housing n'avait pas de colonnes — c'est le premier problème que j'ai dû résoudre en Power Query."

---

### [00:45 – 01:20] Focus Technique 1 : Power Query (Niveau 1)

🎤 **Script** :
> "La première étape, c'est le nettoyage des données avec Power Query.
>
> Prenons l'exemple du dataset Sentiment : il contenait plus de 150 labels différents — 'Positive', 'Joy', 'Happy', 'Happiness'... tous overlapping.
> J'ai créé une colonne conditionnelle en M pour regrouper tout ça en 3 macro-catégories :
> Positive, Negative, et Neutral.
>
> Résultat ici : 62% de sentiment positif sur 732 posts."

📹 **Visuels** :
- Basculer vers l'onglet **Sentiment**
- Montrer le graphique "Top 15 Sentiment Labels" (illustre le problème des 150+ labels)
- Pointer la KPI "Positive Sentiment 62%"
- Montrer brièvement le fichier `sentiment_grouping_logic.m` dans VS Code / Notepad

---

### [01:20 – 02:00] Focus Technique 2 : DAX (Niveau 2)

🎤 **Script** :
> "Maintenant, le plus intéressant : l'analyse DAX sur le dataset Churn.
>
> J'ai découvert que les clients avec un International Plan ont un taux de churn de 42%,
> contre seulement 11% pour les autres.
> C'est 3,8 fois plus élevé — c'est le signal le plus fort de tout le dataset.
>
> Cette mesure DAX utilise CALCULATE pour modifier le contexte de filtre :
> elle dit à Power BI 'calcule le taux de churn, mais seulement pour les clients avec International Plan'.
>
> J'ai aussi utilisé RANKX pour classer les états par volume de churn —
> Texas et New Jersey arrivent en tête avec 18 clients churned chacun."

📹 **Visuels** :
- Basculer vers l'onglet **Churn Analysis**
- Montrer le graphique "Churn by International Plan" (42% vs 11%)
- Afficher brièvement l'onglet **DAX Reference**
- Zoomer sur la mesure `Intl Plan Churn Rate %` et `State Churn Rank`

---

### [02:00 – 02:20] Modélisation et GitHub

🎤 **Script** :
> "Tout le code est documenté et organisé sur GitHub selon une architecture professionnelle :
> datasets sources, transformations Power Query en M, mesures DAX, documentation et rapport interactif.
>
> Le dashboard HTML est également disponible sans installation — accessible directement dans le navigateur."

📹 **Visuels** :
- Montrer rapidement l'arborescence GitHub (ou VS Code avec les fichiers)
- Ouvrir le fichier `level2_basic_measures.dax`

---

### [02:20 – 02:45] Impact et Conclusion

🎤 **Script** :
> "Ce projet m'a permis de maîtriser la chaîne complète :
> import, nettoyage, modélisation en Star Schema, mesures DAX, et visualisation.
>
> Ce sont des compétences directement transférables à des projets d'impact —
> que ce soit pour analyser des données de santé publique au Sahel,
> ou pour aider des startups africaines à prendre de meilleures décisions data.
>
> Merci à toute l'équipe Codveda pour cette opportunité !
> Le repository GitHub est en description. N'hésitez pas à laisser un commentaire.
> Hashtag CodvedaJourney !"

📹 **Visuels** :
- Retour caméra face — enthousiaste
- Afficher le lien GitHub à l'écran

---

## CHECKLIST PRE-ENREGISTREMENT

```
□ Résolution écran : 1920×1080 minimum
□ Microphone testé (pas de bruit de fond)
□ Dashboard HTML ouvert dans Chrome ou Firefox (plein écran)
□ Fichiers DAX ouverts dans VS Code (thème sombre recommandé)
□ GitHub repo public et accessible
□ Lumière correcte si caméra utilisée
□ Vêtements professionnels
□ Script imprimé ou visible sur second écran
□ Loom / OBS configuré et testé
□ Durée cible : max 3 minutes
```

---

## TITRE VIDÉO RECOMMANDÉ

```
"Power BI Data Analytics Internship — Codveda Technologies | DAX + Power Query + Churn Analysis"
```

---

## DESCRIPTION VIDÉO LINKEDIN

```
📊 Mon projet d'internship Power BI avec Codveda Technologies !

Dans cette vidéo :
→ Pipeline complet : 5 datasets · 4 763 enregistrements
→ Power Query : nettoyage, fusion, colonnes conditionnelles
→ DAX : CALCULATE, RANKX, SWITCH, intelligence temporelle
→ Insight clé : 42% de churn chez les clients International Plan (3.8× plus élevé)

🔗 GitHub : [lien]
📁 Dashboard interactif inclus

#CodvedaJourney #CodvedaExperience #FutureWithCodveda #PowerBI #DAX #DataAnalytics
```
